﻿using Microsoft.AspNetCore.Mvc;
using NuGet.Protocol.Core.Types;
using OrderManagementDemo.Model;
using OrderManagementDemo.Repository;
using OrderManagementDemo.ViewModel;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace OrderManagementDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderRepository _repository;

        //DI - Dependency Injection
        public OrdersController(IOrderRepository repository)
        {
            _repository = repository;
        }

        #region 1 - Get all Orders - search all
        [HttpGet]
        public async Task<ActionResult<IEnumerable<OrderTable>>> GetAllOrderss()
        {
            var orders = await _repository.GetTblOrder();
            if (orders == null)
            {
                return NotFound("No employees found");
            }
            return Ok(orders);
        }
        #endregion

        #region 2 - Get all from viewModel 
        [HttpGet("vm")]
        public async Task<ActionResult<IEnumerable<CustOrderViewModel>>> GetAllEmployeesByViewModel()
        {
            var orders = await _repository.GetOrderViewModel();
            if (orders == null)
            {
                return NotFound("No orders found");
            }
            return Ok(orders);
        }

        #endregion

        #region 3 - Get Orders - Search By Id
        [HttpGet("{id}")]
        public async Task<ActionResult<OrderTable>> GetCustOrdersById(int id)
        {
            var order = await _repository.GetOrderById(id);
            if (order == null)
            {
                return NotFound("No orders found");
            }
            return Ok(order);
        }

        #endregion

        #region 4 insert an employee return employee record
        [HttpPost]
        public async Task<ActionResult<OrderTable>> postordersReturnRecord(OrderTable order)
        {
            if (ModelState.IsValid)
            {
                var neworder = await _repository.postordersReturnRecord(order);
                if (neworder != null)
                {
                    return Ok(neworder);
                }
                else
                {
                    return NotFound();
                }

            }
            return BadRequest();

        }
        #endregion
        #region 5 insert an employee return employee by id
        [HttpPost("v1")]
        public async Task<ActionResult<int>> postTblorderReturnId(OrderTable order)
        {
            if (ModelState.IsValid)
            {
                var neworderid = await _repository.postTblorderReturnId(order);
                if (neworderid != null)
                {
                    return Ok(neworderid);
                }
                else
                {
                    return NotFound();
                }

            }
            return BadRequest();

        }
        #endregion

        #region update employee
        [HttpPut("{id}")]
        public async Task<ActionResult<OrderTable>> putTblorder(int id, OrderTable order)
        {
            if (ModelState.IsValid)
            {
                var updateorder = await _repository.putTblorder(id, order);
                if (updateorder != null)
                {
                    return Ok(updateorder);
                }
                else
                {
                    return NotFound();
                }

            }
            return BadRequest();

        }
        #endregion
        #region  7  - Delete an Employee
        [HttpDelete("{id}")]
        public IActionResult DeleteTblorder(int id)
        {
            try
            {
                var result = _repository.DeleteTblorder(id);

                if (result == null)
                {
                    //if result indicates failure or null
                    return NotFound(new
                    {
                        success = false,
                        message = "order could not be deleted or not found"
                    });
                }
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new { success = false, message = "An unexpected error occurs" });
            }
        }
        #endregion
























    }
}
