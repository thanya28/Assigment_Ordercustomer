﻿using Microsoft.AspNetCore.Mvc;
using OrderManagementDemo.Model;
using OrderManagementDemo.ViewModel;

namespace OrderManagementDemo.Repository
{
    public interface IOrderRepository
    {
        #region - Get all orders from DB - Search All
        //Get all employees from DB - Search All
        public Task<ActionResult<IEnumerable<OrderTable>>> GetTblOrder();
        #endregion

        #region - Get all orders using ViewModel
        public Task<ActionResult<IEnumerable<CustOrderViewModel>>> GetOrderViewModel();
        #endregion

        #region 3 - Get an order based on Id
        public Task<ActionResult<OrderTable>> GetOrderById(int id);
        #endregion
        #region insert order
        public Task<ActionResult<OrderTable>> postordersReturnRecord(OrderTable tblorder);
        #endregion
        #region get inserted order id
        public Task<ActionResult<int>> postTblorderReturnId(OrderTable tblorder);
        #endregion
        #region get inserted order id
        public Task<ActionResult<OrderTable>> putTblorder(int id, OrderTable tblorder);

        #endregion
        #region 
        public JsonResult DeleteTblorder(int id);
        #endregion
    }
}
