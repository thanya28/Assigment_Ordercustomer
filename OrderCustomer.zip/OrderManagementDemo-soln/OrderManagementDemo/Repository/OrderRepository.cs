﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OrderManagementDemo.Model;
using OrderManagementDemo.ViewModel;

namespace OrderManagementDemo.Repository
{
    public class OrderRepository : IOrderRepository
    {
        private readonly OrderMgntDbContext _context;

        public OrderRepository(OrderMgntDbContext context)
        {
            _context = context;
        }

        #region 1 - Get all Orders
        public async Task<ActionResult<IEnumerable<OrderTable>>> GetTblOrder()
        {
            try
            {
                if (_context != null)
                {
                    return await _context.OrderTables.Include(order => order.Customer).Include(order => order.OrderItem).ToListAsync();
                }
                //Returns an empty list if context is null
                return new List<OrderTable>();
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        #endregion

        #region 2 - Order ViewModel
        public async Task<ActionResult<IEnumerable<CustOrderViewModel>>> GetOrderViewModel()
        {
            //LINQ
            try
            {
                if (_context != null)
                {
                    //LINQ
                    return await (from o in _context.OrderTables
                                  join c in _context.Customers on o.CustomerId equals c.CustomerId
                                  join oi in _context.OrderItems on o.OrderItemId equals oi.OrderItemId
                                  join i in _context.Items on oi.ItemId equals i.ItemId
                                  select new CustOrderViewModel
                                  {
                                      CustomerId = c.CustomerId,
                                      CustomerName = c.CustomerName,
                                      ItemName = i.ItemName,
                                      Price = i.Price,
                                      Quantity = oi.Quantity,
                                      OrderDate = o.OrderDate
                                  }).ToListAsync();

                }
                //Returns an empty list if context is null
                return new List<CustOrderViewModel>();
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        #endregion

        #region 3 - Get an order by its Id
        public async Task<ActionResult<OrderTable>> GetOrderById(int id)
        {
            try
            {
                if (_context != null)
                {
                    var custOrder = await _context.OrderTables.Include(order => order.Customer).Include(order => order.OrderItem).FirstOrDefaultAsync(e => e.OrderId == id);
                    return custOrder;
                }
                return null;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        
        #endregion
        #region 4-insert orders and display order details
        public async Task<ActionResult<OrderTable>> postordersReturnRecord(OrderTable order)
        {
            try
            {//check idf employee object is not null
                if (order == null)
                {
                    throw new ArgumentNullException(nameof(order), "order data is null");

                }
                // ensure context is not null
                if (_context == null)
                {
                    throw new InvalidOperationException("Database context is not initialized.");
                }
                //add the employee record to the dbcontext
                await _context.OrderTables.AddAsync(order);

                //save changes to the database
                await _context.SaveChangesAsync();
                //retrive the employee with the related departement
                var customerorder = await _context.OrderTables.Include(e => e.Customer)
                    .FirstOrDefaultAsync(e => e.OrderId == order.OrderId);
                return customerorder;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        #endregion
        #region 5- get orders id 
        public async Task<ActionResult<int>> postTblorderReturnId(OrderTable order)
        {
            try
            {//check idf employee object is not null
                if (order == null)
                {
                    throw new ArgumentNullException(nameof(order), "order data is null");

                }
                // ensure context is not null
                if (_context == null)
                {
                    throw new InvalidOperationException("Database context is not initialized.");
                }
                //add the employee record to the dbcontext
                await _context.OrderTables.AddAsync(order);

                //save changes to the database
                var changesRecord = await _context.SaveChangesAsync();
                if (changesRecord > 0)
                {
                    return order.OrderId;
                }
                else
                {
                    throw new Exception("failed to save order record to the database");
                }

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<ActionResult<OrderTable>> putTblorder(int id, OrderTable order)
        {
            try
            {//check idf employee object is not null
                if (order == null)
                {
                    throw new ArgumentNullException(nameof(order), "order data is null");

                }
                // ensure context is not null
                if (_context == null)
                {
                    throw new InvalidOperationException("Database context is not initialized.");
                }
                //Find the employee by id
                var existingorder = await _context.OrderTables.FindAsync(id);
                if (existingorder == null)
                {
                    return null;
                }

                //map values with fields - update
                existingorder.OrderItemId = order.OrderItemId;
                existingorder.CustomerId = order.CustomerId;
                existingorder.Customer = order.Customer;
                existingorder.OrderItem = order.OrderItem;
                existingorder.OrderDate = order.OrderDate;
              



                //save changes to the database
                await _context.SaveChangesAsync();
                //retrive the employee with the related departement
                var customeroder = await _context.OrderTables.Include(e => e.OrderId)
                    .FirstOrDefaultAsync(e => e.OrderId == order.OrderId);
                return customeroder;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public JsonResult DeleteTblorder(int id)
        {
            try
            {//check idf employee object is not null
                if (id <= 0)
                {
                    return new JsonResult(new
                    {
                        success = false,
                        message = "Invalid order id"

                    })
                    {
                        StatusCode = StatusCodes.Status400BadRequest
                    };

                }
                // ensure context is not null
                if (_context == null)
                {
                    return new JsonResult(new
                    {
                        success = false,
                        message = "Database coontext is not initialized"

                    })
                    {
                        StatusCode = StatusCodes.Status500InternalServerError
                    };
                }
                //Find the employee by id
                var existingorder = _context.OrderTables.Find(id);
                if (existingorder == null)
                {
                    return new JsonResult(new
                    {
                        success = false,
                        message = "order  not found"

                    })
                    {
                        StatusCode = StatusCodes.Status400BadRequest
                    };
                }
                //remove

                _context.OrderTables.Remove(existingorder);



                //save changes to the database
                _context.SaveChangesAsync();


                return new JsonResult(new
                {
                    success = true,
                    message = "order deleted successfully"

                })
                {
                    StatusCode = StatusCodes.Status200OK
                };

            }
            catch (Exception ex)
            {
                return new JsonResult(new
                {
                    success = false,
                    message = "Database coontext is not initialized"

                })
                {
                    StatusCode = StatusCodes.Status500InternalServerError
                };
            }

        }
        #endregion
    }
}
